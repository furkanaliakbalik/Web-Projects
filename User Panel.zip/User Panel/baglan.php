<?php
     $servername = "localhost";
     $database = "kontrol";
     $username = "root";
     $password = "";
// Create connection
$conn = mysqli_connect($servername, $username, $password, $database);

?>