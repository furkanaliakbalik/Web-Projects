<?php
session_start();
include_once('baglan.php');
$kullanici=$_POST["xkullanicigiris"];
$sifre=$_POST["xgirissifre"];
$deger=$_POST["xguvenlik"];
$sql="select * from users where user_name='$kullanici' and password='$sifre'";
$sorgu=mysqli_query($conn,$sql);
$dizi=mysqli_fetch_array($sorgu);
if($_SESSION['guven']==$deger)
{
	if($dizi!=0)
	{
			header("location:sayfalar.php");
	}
	else
	{
		echo "Kullanıcı Adı Veya Şifre Hatalı ";
		echo "<a href=index.php><button> Giris</button></a>";
	}
}
else
{
	echo "Güvenlik Kodunu yanlış Girdiniz!";
}	
?>