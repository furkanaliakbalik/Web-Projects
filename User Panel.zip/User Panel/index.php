<?php
session_start();
include_once('baglan.php');
?>

<!DOCTYPE html>
<html lang="en" >

<head>
  <meta charset="UTF-8">
  <title>Kullanıcı Giris</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/meyer-reset/2.0/reset.min.css">
  <link rel='stylesheet' href='https://fonts.googleapis.com/css?family=Roboto:400,100,300,500,700,900'>
  <link rel='stylesheet' href='https://fonts.googleapis.com/css?family=Montserrat:400,700'>
  <link rel='stylesheet' href='https://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css'><link rel="stylesheet" href="./style.css">
</head>

<body>

<div class="container">
  <div class="info">
    <h1>Üye Giris Formu</h1>
  </div>
</div>

<div class="form">
  <p> <img src="img/s.png" width="225" height="225" alt=""></p>
  <p>&nbsp;</p>
  <form action="login.php" class="login-form" method="POST">
    <input type="text" placeholder="Kullanıcı Adı" name="xkullanicigiris"/>
    <input type="password" placeholder="Parola" name="xgirissifre"/>
    <?php 
    $guvenlik=rand(1000,9000); 
    $deger=$guvenlik;
    $_SESSION['guven']=$deger;
    ?>
    <label>Güvenlik Kodu=<?php echo $deger; ?></label>
    <input type="text" placeholder="kod:" maxlength="4" name="xguvenlik"/>
    <input type="submit" name="xgiris" value="GIRIS">
  </form>
</div>

 <script src='https://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script><script  src="./script.js"></script>

</body>
</html>