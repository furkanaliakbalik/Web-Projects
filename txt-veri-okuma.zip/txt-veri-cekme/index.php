<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body style="text-align: center">
    <div>
<strong>TXT DOSYA 1</strong><br>
<?php
$dosya= fopen("Veri1.txt", "r") or die("Dosya bulunamadı!");
echo fread($dosya,filesize("Veri1.txt"));
fclose($dosya);
?><br><br>


<strong>TXT DOSYA 2</strong><br>
<?php
$dosya= fopen("Veri2.txt", "r") or die("Dosya bulunamadı!");
echo fread($dosya,filesize("Veri2.txt"));
fclose($dosya);
?><br><br>
<strong>TXT DOSYA 3</strong><br>
<?php
$dosya= fopen("Veri3.txt", "r") or die("Dosya bulunamadı!");
echo fread($dosya,filesize("Veri3.txt"));
fclose($dosya);
?><br><br>
<strong>TXT DOSYA 4</strong><br>
<?php
$dosya= fopen("Veri4.txt", "r") or die("Dosya bulunamadı!");
echo fread($dosya,filesize("Veri4.txt"));
fclose($dosya);
?><br><br>
<strong>TXT DOSYA 5</strong><br>
<?php
$dosya= fopen("Veri5.txt", "r") or die("Dosya bulunamadı!");
echo fread($dosya,filesize("Veri5.txt"));
fclose($dosya);
?>
</div>
</body>
</html>