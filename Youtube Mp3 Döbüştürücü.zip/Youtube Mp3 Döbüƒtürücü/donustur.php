<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Youtube mp3 Donusturucu</title>
<link href="css/style.css" rel="stylesheet" type="text/css">
<style>
.btn4 {
background-color:#00008b;
border:1px solid #1a18ab;
display:inline-block;
cursor:pointer;
color:white;
font-family:Arial;
font-size:19px;
padding:20px 63px;
text-decoration:none;
text-shadow:0px 1px 0px #272d66;
border-radius:30px;
}
.btn4:hover {
background-color:#2d2abf;
}
.btn4:active {
position:relative;
top:1px;
}

</style>
<link rel="shortcut icon" href="img/logo.ico" />
</head>

<body>
<div id="ust">
  <div id="ustsol">Youtube Mp3 Dönüştürücü </div>
  <div id="ustsag">--  <a href="index.html">Anasayfa</a>  -  <a href="telif.html">Telif Hakkı</a>  -  <a href="destek.html">Bagış</a>  --</div>
</div>
<div id="ortasonuc">

  <div id="ortasonucbas">
    <h1>Youtube Mp3 Dönüştürücü <button onclick="window.location.href='http://youtubemp3.rf.gd/'" class="btn4">Geri</button></h1>
  </div>
<?php
$muziklink=$_POST["url"];
?>
<div id="ortasonucdonusturucu">
<iframe 
id="widgetv2Api" src="https://y2mate.com.co/<?php echo $muziklink; ?>"
 width="100%" height="1024px" allowtransparency="true" scrolling="no" style="border:none">
</iframe>
</div>
  
</div>
	<div id="atl">  <center> <h5>©2022 -Projem</h5> </center></div>
</body>
</html>
